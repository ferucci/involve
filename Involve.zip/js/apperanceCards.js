import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export const aCards = () => {
  const cards = gsap.utils.toArray('.item');
  const container = document.querySelector('.items__inner');
  const viewportHeight = window.innerHeight;

  // // Удаляем автоматический pin-spacer
  // gsap.set(container, { position: 'relative' });

  // Устанавливаем начальное положение карточек
  gsap.set(cards, {
    y: (i) => i * 75, // Каждая следующая карточка ниже
    opacity: (i) => i === 0 ? 1 : 0.3 // Первая видна, остальные полупрозрачные
  });

  const master = gsap.timeline();

  master
    .from(container, {
      scrollTrigger: {
        trigger: container,
        start: '-100% 0',
        scrub: true,
        pin: true
      },
    })
    .to(cards, {
      scrollTrigger: {
        trigger: container,
        start: 'bottom 100%',
        scrub: true,
        markers: true,
      },
      stagger: .25,
      y: 0,
      opacity: 1
    })

};
