import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";

// Регистрируем плагин ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

export const aVideo = () => {

  const screenWidth = window.innerWidth;
  const screenHeight = window.innerHeight;
  const video = document.querySelector('.expand-video');

  // Получаем начальные размеры и позицию видео
  const videoRect = video.getBoundingClientRect();
  const initialWidth = videoRect.width;
  const initialHeight = videoRect.height;

  // Рассчитываем масштаб и смещение
  const scaleX = screenWidth / initialWidth;
  const scaleY = screenHeight / initialHeight;
  const finalScale = Math.max(scaleX, scaleY); // Максимальный масштаб для заполнения экрана

  // Вычисляем, насколько нужно сдвинуть видео, чтобы оно расширялось равномерно
  const offsetX = (screenWidth - initialWidth) / 2 - videoRect.left;
  const offsetY = (screenHeight - initialHeight) / 2 - videoRect.top;

  // Флаг для отслеживания состояния анимации
  let isVideoExpanded = false;

  // Анимация увеличения видео
  gsap.fromTo(video, {
    x: 0,
    y: 0,
    scale: 1,
    opacity: 1,
  }, {
    x: offsetX, // Смещаем видео так, чтобы оно расширялось из центра
    y: offsetY,
    scale: finalScale,
    opacity: 0.1,
    duration: 5,
    ease: "power2.out",
    transformOrigin: "center center", // Масштабирование из центра
    scrollTrigger: {
      trigger: ".container",
      start: "top top",
      end: "bottom bottom",
      end: "+=3500", // Фиксированная дистанция скролла
      scrub: true, // Плавное привязывание к скроллу
      pin: true, // Ключевой параметр - фиксирует контент
      // markers: true // Для отладки

    },
    onStart: () => {
      video.style.zIndex = 99; // Поднимаем видео над другими элементами
    }
  });
}